# Comandos Sugeridos para Desenvolvimento

## Comandos Essenciais de Desenvolvimento

### Iniciar Servidor de Desenvolvimento
```bash
# Comando principal (Python)
python -m http.server 8000

# Alternativa (Node.js)
npx live-server
```

### Explorar Código
```bash
# Listar estrutura do projeto
dir /s /b *.js
dir /s /b *.html
dir /s /b *.css

# Buscar padrões específicos
findstr /s /i "function.*Multi" *.js
findstr /s /i "CLAUDE-FISCAL" *.js
```

### Debug e Desenvolvimento
- **Browser DevTools**: F12 para console e debugging
- **Log Window**: Interface própria da aplicação para logs
- **Network Tab**: Para verificar carregamento de módulos ES6

### Verificação de Estado
```bash
# Ver status do refatoramento
findstr /s /i "TODO\|FIXME\|CLAUDE" *.js

# Verificar funções implementadas vs pendentes  
findstr /s /i "async function.*process" script.js
```

### Comandos Git Recomendados
```bash
git status
git log --oneline -10
git diff HEAD~1
```

## Comandos Específicos do Projeto

### Verificar Implementação Multiperíodos
```bash
findstr /s /i "multiPeriodData\|processMultiple" script.js
```

### Analisar Estrutura Modular
```bash
dir js\src /s /b
```

### Teste Manual
1. Servir aplicação via HTTP
2. Fazer login (admin/admin0000)
3. Testar upload SPED
4. Verificar logs na interface