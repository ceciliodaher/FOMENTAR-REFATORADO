# Comandos de Desenvolvimento

## Servidor de Desenvolvimento
Como este é um projeto frontend-only sem package.json, use um servidor web estático:

```bash
# Python (mais comum)
python -m http.server 8000

# Node.js (se disponível)
npx live-server

# PHP
php -S localhost:8000

# Acesso: http://localhost:8000
```

**IMPORTANTE**: A aplicação DEVE ser servida via HTTP (não file://) devido às restrições dos módulos ES6.

## Comandos Windows
- **Listar arquivos**: `dir` (equivalente ao `ls` Unix)
- **Navegar**: `cd caminho`
- **Buscar**: `findstr "padrão" arquivo.txt` (equivalente ao `grep`)
- **Encontrar arquivos**: `dir /s /b *.js` (equivalente ao `find`)

## Testing/Linting/Formatting
- **Não há**: Este projeto não possui sistema de build, testes automatizados ou linting configurado
- **Verificação**: Usar DevTools do navegador para debugging
- **Logging**: Sistema interno via classe Logger com janela de log na UI

## Comandos Git
```bash
git status
git add .
git commit -m "mensagem"
git push
```

## Estrutura de Arquivos Principais
- `sped-web-app.html`: Interface principal
- `script.js`: Código legado (a ser migrado)
- `js/src/`: Nova estrutura modular
- `css/main.css`: Estilos principais