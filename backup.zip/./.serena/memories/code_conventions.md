# Convenções de Código

## Estilo JavaScript
- **Formato**: ES6 módulos com import/export
- **Variáveis**: camelCase (ex: `multiPeriodData`, `spedFileContent`)
- **Constantes**: UPPER_SNAKE_CASE (ex: `CFOP_ENTRADAS_INCENTIVADAS`)
- **Funções**: camelCase com verbos descritivos (ex: `processMultipleSpeds`, `analisarCodigosC197D197`)
- **Classes**: PascalCase (ex: `SpedWebApp`, `ExcelGenerator`)

## Padrões de Nomeação Específicos
- **Variáveis de período múltiplo**: `multiPeriodData`, `progoiasMultiPeriodData`
- **Registros SPED**: `registrosCompletos`, `progoiasRegistrosCompletos`
- **Códigos de correção**: `codigosCorrecao`, `progoiasCodigosCorrecao`
- **Flags booleanas**: `isMultiplePeriods`, `temCodigosC197D197`

## Estrutura de Comentários
- **Seções principais**: `// --- Seção ---`
- **CLAUDE-FISCAL**: Marcador para código específico do refatoramento
- **Variáveis globais**: Comentários descritivos no topo

## Padrões de Dados
- **Períodos**: Formato "MM/YYYY" (ex: "01/2024")
- **CFOPs**: Strings de 4 dígitos
- **Empresas**: Objeto com `nome`, `cnpj`, `periodo`
- **Logs**: `addLog(mensagem, tipo)` onde tipo = 'info'|'warn'|'error'

## Convenções de Interface
- **IDs**: camelCase (ex: `processMultipleSpeds`, `exportComparative`)
- **Classes CSS**: kebab-case (Bootstrap padrão)
- **Event listeners**: Funções nomeadas (ex: `handleImportModeChange`)