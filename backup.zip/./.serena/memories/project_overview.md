# FOMENTAR-REFATORADO - Visão Geral do Projeto

## Propósito
Aplicação web frontend-only para cálculo fiscal e processamento de arquivos SPED (Sistema Público de Escrituração Digital) para programas de incentivo fiscal do estado de Goiás (FOMENTAR, ProGoiás, LogPRODUZIR).

## Tecnologias Utilizadas
- **Frontend**: Vanilla JavaScript ES6 com módulos
- **UI Framework**: Bootstrap 5.3
- **Ícones**: Font Awesome 6.4
- **Excel**: xlsx-populate para geração de planilhas
- **Codificação**: Detecção automática UTF-8/ISO-8859-1
- **Arquitetura**: ES6 modular sem build process

## Estado Atual do Refatoramento
O projeto foi refatorado de um script monolítico de ~695k caracteres para uma arquitetura modular ES6:

### Estrutura de Diretórios (Alvo)
```
js/src/
├── main.js                 # Controlador principal (SpedWebApp)
├── core/                   # Utilitários e constantes
├── sped/                   # Processamento de arquivos SPED
├── modules/                # Calculadoras por programa
├── ui/                     # Gerenciamento de interface
└── excel/                  # Geração de relatórios Excel
```

### Estado da Migração
- **script.js**: Script original ainda em uso (código legado)
- **js/src/**: Nova estrutura modular parcialmente implementada
- **Funcionalidades**: Sistema de autenticação, processamento SPED básico
- **Pendentes**: Migração completa do multiperíodos e funções específicas

## Programas Fiscais Suportados
1. **FOMENTAR/PRODUZIR/MICROPRODUZIR**: 70% padrão, Quadros A/B/C
2. **ProGoiás**: 74% → 62% declinante por ano
3. **LogPRODUZIR**: Categorias I/II/III (50%/73%/80%)